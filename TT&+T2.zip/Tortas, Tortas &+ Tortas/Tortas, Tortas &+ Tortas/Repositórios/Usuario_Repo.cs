﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using Tortas__Tortas____Tortas.Entidades;

namespace Tortas__Tortas____Tortas.Repositórios
{
    class Usuario_Repo
    {
        private readonly string _connectionString;

        public Usuario_Repo(string connectionString)
        {
            _connectionString = connectionString;
        }

        public void cadastrar(usuario User)
        {
            using (var connection = new MySqlConnection(_connectionString))
            {
                connection.Open();

                string query1 = "SELECT COUNT(*) FROM usuario WHERE name = @Username";
                using (var checkCommand = new MySqlCommand(query1, connection))
                {
                    checkCommand.Parameters.AddWithValue("@Username", User.name);
                    long count = (long)checkCommand.ExecuteScalar();

                    if (count > 0)
                    {
                        MessageBox.Show("Usuário já cadastrado.\nEscolha outro nome.");
                        return;
                    }
                }

                string query2 = "INSERT INTO usuario (name, senha) VALUES (@Username, @Senha)";
                using (var insertCommand = new MySqlCommand(query2, connection))
                {
                    insertCommand.Parameters.AddWithValue("@Username", User.name);
                    insertCommand.Parameters.AddWithValue("@Senha", User.senha);
                    insertCommand.ExecuteNonQuery();
                }

                MessageBox.Show("Usuário cadastrado com sucesso!");
            }
        }

        public bool entrar(usuario User)
        {
            using (var connection = new MySqlConnection(_connectionString))
            {
                connection.Open();

                string query = "SELECT * FROM usuario WHERE name = @Username";
                using (var command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Username", User.name);

                    using (var reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            string senhaSalva = reader.GetString("senha");

                            if (User.senha == senhaSalva)
                            {
                                User.id = reader.GetInt32("id");
                                User.grana = reader.GetInt32("grana");
                                User.padeiros = reader.GetInt32("padeiros");
                                User.caixistas = reader.GetInt32("caixistas");
                                User.Upg_Cob = reader.GetInt32("Upg_Cob");
                                User.Upg_conf1 = reader.GetInt32("Upg_conf1");
                                User.Upg_conf2 = reader.GetInt32("Upg_conf2");
                                User.Upg_cerej = reader.GetInt32("Upg_cerej");
                                User.Upg_Bprice = reader.GetInt32("Upg_Bprice");
                                User.Upg_Mprice = reader.GetInt32("Upg_Mprice");
                                User.Bmassa = reader.GetDouble("Bmassa");
                                User.Bcobert = reader.GetDouble("Bcobert");
                                User.Bconf = reader.GetDouble("Bconf");
                                User.Bcerej = reader.GetDouble("Bcerej");
                                User.price_bonus = reader.GetDouble("price_bonus");
                                User.price_mult = reader.GetDouble("price_mult");

                                return true;
                            }
                            else
                            {
                                MessageBox.Show("Senha incorreta.");
                                return false;
                            }
                        }
                        else
                        {
                            MessageBox.Show("Usuário não encontrado.");
                            return false;
                        }
                    }
                }
            }
        }

        public void Salvar(usuario usuario)
        {
            using (var connection = new MySqlConnection(_connectionString))
            {
                connection.Open();

                string query = @"
            UPDATE usuario SET
                grana = @Grana,
                padeiros = @Padeiros,
                caixistas = @Caixistas,
                Upg_Cob = @Upg_Cob,
                Upg_conf1 = @Upg_conf1,
                Upg_conf2 = @Upg_conf2,
                Upg_cerej = @Upg_cerej,
                Upg_Bprice = @Upg_Bprice,
                Upg_Mprice = @Upg_Mprice,
                Bmassa = @Bmassa,
                Bcobert = @Bcobert,
                Bconf = @Bconf,
                Bcerej = @Bcerej,
                price_bonus = @PriceBonus,
                price_mult = @PriceMult
            WHERE id = @Id";

                using (var command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Grana", usuario.grana);
                    command.Parameters.AddWithValue("@Padeiros", usuario.padeiros);
                    command.Parameters.AddWithValue("@Caixistas", usuario.caixistas);
                    command.Parameters.AddWithValue("@Upg_Cob", usuario.Upg_Cob);
                    command.Parameters.AddWithValue("@Upg_conf1", usuario.Upg_conf1);
                    command.Parameters.AddWithValue("@Upg_conf2", usuario.Upg_conf2);
                    command.Parameters.AddWithValue("@Upg_cerej", usuario.Upg_cerej);
                    command.Parameters.AddWithValue("@Upg_Bprice", usuario.Upg_Bprice);
                    command.Parameters.AddWithValue("@Upg_Mprice", usuario.Upg_Mprice);
                    command.Parameters.AddWithValue("@Bmassa", usuario.Bmassa);
                    command.Parameters.AddWithValue("@Bcobert", usuario.Bcobert);
                    command.Parameters.AddWithValue("@Bconf", usuario.Bconf);
                    command.Parameters.AddWithValue("@Bcerej", usuario.Bcerej);
                    command.Parameters.AddWithValue("@PriceBonus", usuario.price_bonus);
                    command.Parameters.AddWithValue("@PriceMult", usuario.price_mult);
                    command.Parameters.AddWithValue("@Id", usuario.id);

                    command.ExecuteNonQuery();
                }
            }
        }
        public string GerarHash(string senha)
        {
            using (SHA256 sha = SHA256.Create())
            {
                byte[] bytes = Encoding.UTF8.GetBytes(senha);
                byte[] hash = sha.ComputeHash(bytes);
                return Convert.ToBase64String(hash);
            }
        }
    }
}
