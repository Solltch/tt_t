﻿using MySql.Data.MySqlClient;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Tortas__Tortas____Tortas.Entidades;

namespace Tortas__Tortas____Tortas.Repositórios
{
    class Tortas_Repo
    {
        private readonly string _connectionString;

        public Tortas_Repo(string connectionString)
        {
            _connectionString = connectionString;
        }

        public void cozinhar(Tortas tortas, double Bmassa, double Bcobert, double Bconf, double Bcerej, int usuarioId)
        {
            List<Tortas> tortas_list = new List<Tortas>();
            using (var connection = new MySqlConnection(_connectionString))
            {
                connection.Open();

                string query1 = "SELECT * FROM tortas WHERE usuario_id = @usuario_id";
                using (var command = new MySqlCommand(query1, connection))
                {
                    command.Parameters.AddWithValue("@usuario_id", usuarioId);
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            tortas_list.Add(new Tortas
                            {
                                id = reader.GetInt32("id"),
                                massa = reader.GetInt32("massa"),
                                cobert = reader.GetInt32("cobert"),
                                conf1 = reader.GetInt32("conf1"),
                                conf2 = reader.GetInt32("conf2"),
                                cerej = reader.GetInt32("cerej"),
                                preco = reader.IsDBNull(reader.GetOrdinal("preco")) ? 0 : reader.GetDouble("preco"),
                                quant = reader.GetInt32("quant"),
                                precotodas = reader.GetDouble("precotodas"),
                                usuario_id = usuarioId
                            });
                        }
                    }
                }

                double preco = PrecoTorta(tortas.massa, tortas.cobert, tortas.conf1, tortas.conf2, tortas.cerej, Bmassa, Bcobert, Bconf, Bcerej);
                double precotodas = preco * 1;

                bool existe = false;
                for (int i = 0; i < tortas_list.Count; i++)
                {
                    if (tortas_list[i].massa == tortas.massa &&
                        tortas_list[i].cobert == tortas.cobert &&
                        tortas_list[i].conf1 == tortas.conf1 &&
                        tortas_list[i].conf2 == tortas.conf2 &&
                        tortas_list[i].cerej == tortas.cerej)
                    {
                        int novaQuant = tortas_list[i].quant + 1;
                        double novoPrecoTotal = preco * novaQuant;

                        string query3 = @"UPDATE tortas SET quant = @quant, preco = @preco, precotodas = @precotodas WHERE id = @id";
                        using (var command = new MySqlCommand(query3, connection))
                        {
                            command.Parameters.AddWithValue("@quant", novaQuant);
                            command.Parameters.AddWithValue("@preco", preco);
                            command.Parameters.AddWithValue("@precotodas", novoPrecoTotal);
                            command.Parameters.AddWithValue("@id", tortas_list[i].id);
                            command.ExecuteNonQuery();
                        }

                        existe = true;
                        break;
                    }
                }

                if (!existe)
                {
                    string Query2 = @"INSERT INTO tortas (massa, cobert, conf1, conf2, cerej, quant, preco, precotodas, usuario_id) 
                              VALUES (@massa, @cobert, @conf1, @conf2, @cerej, @quant, @preco, @precotodas, @usuario_id)";
                    using (var command = new MySqlCommand(Query2, connection))
                    {
                        command.Parameters.AddWithValue("@massa", tortas.massa);
                        command.Parameters.AddWithValue("@cobert", tortas.cobert);
                        command.Parameters.AddWithValue("@conf1", tortas.conf1);
                        command.Parameters.AddWithValue("@conf2", tortas.conf2);
                        command.Parameters.AddWithValue("@cerej", tortas.cerej);
                        command.Parameters.AddWithValue("@quant", 1);
                        command.Parameters.AddWithValue("@preco", preco);
                        command.Parameters.AddWithValue("@precotodas", precotodas);
                        command.Parameters.AddWithValue("@usuario_id", usuarioId);
                        command.ExecuteNonQuery();
                    }
                }
            }
        }

        public double PrecoTorta(int massa, int cobert, int conf1, int conf2, int cerej, double Bmassa, double Bcobert, double Bconf, double Bcerej)
        {
            double preco = 0;


            switch (massa)
            {
                case -1: preco += 0 * Bmassa; break;
                case 0: preco += 5 * Bmassa; break;
                case 1: preco += 10 * Bmassa; break;
                case 2: preco += 20 * Bmassa; break;
                case 3: preco += 50 * Bmassa; break;
                case 4: preco += 100 * Bmassa; break;
                case 5: preco += 200 * Bmassa; break;
                case 6: preco += 500 * Bmassa; break;
                case 7: preco += 1000 * Bmassa; break;
            }

            switch (cobert)
            {
                case -1: preco += 0 * Bcobert; break;
                case 0: preco += 5 * Bcobert; break;
                case 1: preco += 15 * Bcobert; break;
                case 2: preco += 50 * Bcobert; break;
                case 3: preco += 150 * Bcobert; break;
            }

            switch (conf1)
            {
                case -1: preco += 0 * Bconf; break;
                case 0: preco += 5 * Bconf; break;
                case 1: preco += 7 * Bconf; break;
                case 2: preco += 12 * Bconf; break;
            }

            switch (conf2)
            {
                case -1: preco += 0 * Bconf; break;
                case 0: preco += 5 * Bconf; break;
                case 1: preco += 7 * Bconf; break;
                case 2: preco += 12 * Bconf; break;
            }

            switch (cerej)
            {
                case -1: preco += 0 * Bconf; break;
                case 0: preco += 50 * Bconf; break;
                case 1: preco += 100 * Bconf; break;
                case 2: preco += 300 * Bconf; break;
            }

            return preco;
        }

        public double PrecoVenda(double bonus, double mult, int usuarioId)
        {
            using (var connection = new MySqlConnection(_connectionString))
            {
                connection.Open();
                double preco = 0;

                string query5 = "SELECT SUM(precotodas) AS precototal FROM tortas WHERE usuario_id = @usuario_id";
                using (var command = new MySqlCommand(query5, connection))
                {
                    command.Parameters.AddWithValue("@usuario_id", usuarioId);
                    using (var reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            preco = reader.IsDBNull(reader.GetOrdinal("precototal")) ? 0 : reader.GetDouble("precototal");
                        }
                    }
                }

                preco += bonus * TotalTortas(usuarioId);
                preco *= mult;

                return preco;
            }
        }

        public int TotalTortas(int usuarioId)
        {
            using (var connection = new MySqlConnection(_connectionString))
            {
                connection.Open();
                int total = 0;

                string query4 = "SELECT SUM(quant) AS soma FROM tortas WHERE usuario_id = @usuario_id";
                using (var command = new MySqlCommand(query4, connection))
                {
                    command.Parameters.AddWithValue("@usuario_id", usuarioId);
                    using (var reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            total = reader.IsDBNull(reader.GetOrdinal("soma")) ? 0 : reader.GetInt32("soma");
                        }
                    }
                }

                return total;
            }
        }

        public void ApagarTortas(int usuarioId)
        {
            using (var connection = new MySqlConnection(_connectionString))
            {
                connection.Open();

                string query6 = "DELETE FROM tortas WHERE usuario_id = @usuario_id;";
                using (var command = new MySqlCommand(query6, connection))
                {
                    command.Parameters.AddWithValue("@usuario_id", usuarioId);
                    command.ExecuteNonQuery();
                }
            }
        }
    }
}
