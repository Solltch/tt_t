﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tortas__Tortas____Tortas.Entidades
{
    class tortas_usuario
    {
        public int id_usuario { get; set; }
        public int id_torta { get; set; }
    }
}
