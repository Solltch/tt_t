using Tortas__Tortas____Tortas.Entidades;
using Tortas__Tortas____Tortas.Reposit�rios;

namespace Tortas__Tortas____Tortas
{
    public partial class MainForm : Form
    {
        private System.Windows.Forms.Timer timer;
        public int tortas = 0;
        public double Custo_m;
        public double Custo_cob;
        public double Custo_conf1;
        public double Custo_conf2;
        public double Custo_cerej;
        public double price;
        public double price_bonus = 1;
        public double price_mult = 2;

        public double custo_pad = 1;
        public int padeiros = 0;
        public int progressoPad;
        public double custo_caixa = 5;
        public int caixista = 0;
        public int progressoCaixa;

        public double Bmassa = 1;
        public double Bcobert = 1;
        public double Bconf = 1;
        public double Bcerej = 1;

        public int Upg_Cob;
        public int Upg_conf1;
        public int Upg_conf2;
        public int Upg_cerej;
        public int Upg_Bprice;
        public int Upg_Mprice;
        public int UpgEmTela = 1;

        public usuario usuarioLogado;

        private HashSet<string> upgradesCriados = new HashSet<string>();

        public double Custo_total;
        public double Grana = 100;
        static string connectionString = "Server=localhost;Port=3306;Database=tt_t;User=root;Password=;ConvertZeroDateTime=True;";
        Tortas torta = new Tortas();
        Tortas_Repo tortaRepo = new Tortas_Repo(connectionString);


        public MainForm(usuario usuario)
        {
            InitializeComponent();

            usuarioLogado = usuario;

            price_bonus = usuarioLogado.price_bonus;
            price_mult = usuarioLogado.price_mult;

            padeiros = usuarioLogado.padeiros;
            caixista = usuarioLogado.caixistas;

            Bmassa = usuarioLogado.Bmassa;
            Bcobert = usuarioLogado.Bcobert;
            Bconf = usuarioLogado.Bconf;
            Bcerej = usuarioLogado.Bcerej;

            Upg_Cob = usuarioLogado.Upg_Cob;
            Upg_conf1 = usuarioLogado.Upg_conf1;
            Upg_conf2 = usuarioLogado.Upg_conf2;
            Upg_cerej = usuarioLogado.Upg_cerej;
            Upg_Bprice = usuarioLogado.Upg_Bprice;
            Upg_Mprice = usuarioLogado.Upg_Mprice;

            timer = new System.Windows.Forms.Timer();
            timer.Interval = 1;
            timer.Tick += Timer_Tick;
            timer.Start();

            massas.BackColor = Color.White;

            Custo_total = Custo_m;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            if (massa_label.TabIndex == -1)
            {
                cuzinho.Enabled = false;
            }
            {
                {
                    if (Upg_Cob == 0)
                    {
                        cobert.Enabled = false;
                        cobert.Visible = false;
                        cobert_label.Enabled = false;
                        cobert_label.Visible = false;
                        custo_cobertura.Enabled = false;
                        custo_cobertura.Visible = false;
                    }
                    else
                    {
                        cobert.Enabled = true;
                        cobert.Visible = true;
                        cobert_label.Enabled = true;
                        cobert_label.Visible = true;
                        custo_cobertura.Enabled = true;
                        custo_cobertura.Visible = true;
                    }
                }
                conf1.Enabled = false;
                conf2.Enabled = false;
                cerej.Enabled = false;
                conf1_label.Enabled = false;
                conf2_label.Enabled = false;
                cerej_label.Enabled = false;
                custo_confeito1.Enabled = false;
                custo_confeito2.Enabled = false;
                custo_cereja.Enabled = false;


                conf1.Visible = false;
                conf2.Visible = false;
                cerej.Visible = false;
                conf1_label.Visible = false;
                conf2_label.Visible = false;
                cerej_label.Visible = false;
                custo_confeito1.Visible = false;
                custo_confeito2.Visible = false;
                custo_cereja.Visible = false;
            }

            if (Upg_Cob > 0)
                UpgEmTela = 0;

            Upg_1.Enabled = false;

            Tortas_label.Text = $"{tortas} Tortas";

        }

        private void button1_Click(object sender, EventArgs e)
        {
            torta.massa = massas.SelectedIndex;
            torta.cobert = cobert.SelectedIndex;
            torta.conf1 = conf1.SelectedIndex;
            torta.conf2 = conf2.SelectedIndex;
            torta.cerej = cerej.SelectedIndex;

            if (Grana > Custo_total - 1)
            {
                Tortas_label.Text = $"{tortaRepo.TotalTortas(usuarioLogado.id)} Tortas";
                Grana -= Custo_total;
                Grana_label.Text = $"A$ {Grana}";
                tortaRepo.cozinhar(torta, Bmassa, Bcobert, Bconf, Bcerej, usuarioLogado.id);
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (cobert_label.Checked)
            {
                cobert.Enabled = true;
            }
            else
            {
                cobert.Enabled = false;
                cobert.SelectedIndex = -1;
            }
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            if (massas.SelectedIndex == -1)
            {
                cuzinho.Enabled = false;
            }
            else cuzinho.Enabled = true;

            price = tortaRepo.PrecoVenda(price_bonus, price_mult, usuarioLogado.id);
            tortas = tortaRepo.TotalTortas(usuarioLogado.id);

            Tortas_label.Text = $"{tortas} Tortas";
            Grana_label.Text = $"A$ {Grana}";
            Price_label.Text = $"Pre�o: A$ {price}";
            Upg_padeiro.Text = $"Novo Padeiro: ${custo_pad}";
            Upg_caixista.Text = $"Novo Caixa: ${custo_caixa}";



            {
                if (Grana > 120)
                {
                    Upg_1.Enabled = true;
                    Upg_1.ForeColor = Color.Black;
                }

                if (Grana > 350 && Upg_conf1 == 0 && !upgradesCriados.Contains("Conf1"))
                {
                    CriarBotaoUpgrade("Confeito 1", 350, Upg_Conf1_Click);
                    upgradesCriados.Add("Conf1");
                }

                if (Grana > 1000 && Upg_conf2 == 0 && !upgradesCriados.Contains("Conf2"))
                {
                    CriarBotaoUpgrade("Confeito 2", 1000, Upg_Conf2_Click);
                    upgradesCriados.Add("Conf2");
                }

                if (Grana > 2000 && Upg_cerej == 0 && !upgradesCriados.Contains("Cerej"))
                {
                    CriarBotaoUpgrade("Cereja", 2000, Upg_Cerej_Click);
                    upgradesCriados.Add("Cerej");
                }
            }

            AtualizarPreco();
            if (Custo_total > Grana)
            {
                Custo_t_label.ForeColor = Color.DarkRed;
            }
            else Custo_t_label.ForeColor = Color.Black;

            

            if (padeiros > 0)
            {
                progressoPad += padeiros/10;

                if (progressoPad >= barra_pad.Maximum)
                {
                    progressoPad = 0;
                    barra_pad.Value = 0;

                    if (Grana > Custo_total - 1)
                    {
                        tortas += 1;
                        Tortas_label.Text = $"{tortaRepo.TotalTortas(usuarioLogado.id)} Tortas";
                        Grana -= Custo_total;
                        Grana_label.Text = $"A$ {Grana}";
                        tortaRepo.cozinhar(torta, Bmassa, Bcobert, Bconf, Bcerej, usuarioLogado.id);
                    }
                }
                else
                {
                    barra_pad.Value = progressoPad;
                }
            }

            if (caixista > 0)
            {
                progressoCaixa += caixista;

                if (progressoCaixa >= barra_caixa.Maximum)
                {
                    progressoCaixa = 0;
                    barra_caixa.Value = 0;

                    if (tortas > 0)
                    {
                        Grana += price;
                        tortas -= 1;

                        Grana_label.Text = $"A$ {Grana}";
                        Tortas_label.Text = $"{tortas} Tortas";
                        price = tortaRepo.PrecoVenda(price_bonus, price_mult, usuarioLogado.id);
                        Price_label.Text = $"Pre�o: A$ {price}";
                        Grana += tortaRepo.PrecoVenda(price_bonus, price_mult, usuarioLogado.id);
                        tortaRepo.ApagarTortas(usuarioLogado.id);
                        price = 0;
                        tortas = 0;

                        Tortas_label.Text = $"{tortas} Tortas";
                        Grana_label.Text = $"A$ {Grana}";
                        Price_label.Text = $"Pre�o: A$ {price}";
                    }
                }
                else
                {
                    barra_caixa.Value = progressoCaixa;
                }
            }

        }

        private void Massas_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (massas.SelectedIndex)
            {
                case -1: Custo_m = 0 * Bmassa; break;
                case 0: Custo_m = 5 * Bmassa; break;
                case 1: Custo_m = 10 * Bmassa; break;
                case 2: Custo_m = 20 * Bmassa; break;
                case 3: Custo_m = 50 * Bmassa; break;
                case 4: Custo_m = 100 * Bmassa; break;
                case 5: Custo_m = 200 * Bmassa; break;
                case 6: Custo_m = 500 * Bmassa; break;
                case 7: Custo_m = 1000 * Bmassa; break;
            }

            custo_massa.Text = $"A${Custo_m}";

            AtualizarPreco();
            if (Custo_total > Grana)
            {
                Custo_t_label.ForeColor = Color.DarkRed;
            }
            else Custo_t_label.ForeColor = Color.Black;
        }

        private void Vender_Click(object sender, EventArgs e)
        {
            Grana += tortaRepo.PrecoVenda(price_bonus, price_mult, usuarioLogado.id);
            tortaRepo.ApagarTortas(usuarioLogado.id);
            price = 0;
            tortas = 0;

            Tortas_label.Text = $"{tortas} Tortas";
            Grana_label.Text = $"A$ {Grana}";
            Price_label.Text = $"Pre�o: A$ {price}";

        }

        private void cobert_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (cobert.SelectedIndex)
            {
                case -1: Custo_cob = 0 * Bcobert; break;
                case 0: Custo_cob = 5 * Bcobert; break;
                case 1: Custo_cob = 10 * Bcobert; break;
                case 2: Custo_cob = 20 * Bcobert; break;
                case 3: Custo_cob = 50 * Bcobert; break;
                case 4: Custo_cob = 100 * Bcobert; break;
                case 5: Custo_cob = 200 * Bcobert; break;
                case 6: Custo_cob = 500 * Bcobert; break;
                case 7: Custo_cob = 1000 * Bcobert; break;
            }

            custo_cobertura.Text = $"A${Custo_cob}";

            AtualizarPreco();
            if (Custo_total > Grana)
            {
                Custo_t_label.ForeColor = Color.DarkRed;
            }
            else Custo_t_label.ForeColor = Color.Black;
        }

        private void conf1_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (conf1.SelectedIndex)
            {
                case -1: Custo_conf1 = 0 * Bconf; break;
                case 0: Custo_conf1 = 5 * Bconf; break;
                case 1: Custo_conf1 = 10 * Bconf; break;
                case 2: Custo_conf1 = 20 * Bconf; break;
                case 3: Custo_conf1 = 50 * Bconf; break;
                case 4: Custo_conf1 = 100 * Bconf; break;
                case 5: Custo_conf1 = 200 * Bconf; break;
                case 6: Custo_conf1 = 500 * Bconf; break;
                case 7: Custo_conf1 = 1000 * Bconf; break;
            }

            custo_confeito1.Text = $"A${Custo_conf1}";

            AtualizarPreco();
            if (Custo_total > Grana)
            {
                Custo_t_label.ForeColor = Color.DarkRed;
            }
            else Custo_t_label.ForeColor = Color.Black;
        }

        private void conf2_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (conf2.SelectedIndex)
            {
                case -1: Custo_conf2 = 0 * Bconf; break;
                case 0: Custo_conf2 = 5 * Bconf; break;
                case 1: Custo_conf2 = 10 * Bconf; break;
                case 2: Custo_conf2 = 20 * Bconf; break;
                case 3: Custo_conf2 = 50 * Bconf; break;
                case 4: Custo_conf2 = 100 * Bconf; break;
                case 5: Custo_conf2 = 200 * Bconf; break;
                case 6: Custo_conf2 = 500 * Bconf; break;
                case 7: Custo_conf2 = 1000 * Bconf; break;
            }

            custo_confeito2.Text = $"A${Custo_conf2}";

            AtualizarPreco();
            if (Custo_total > Grana)
            {
                Custo_t_label.ForeColor = Color.DarkRed;
            }
            else Custo_t_label.ForeColor = Color.Black;
        }

        private void cerej_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (cerej.SelectedIndex)
            {
                case -1: Custo_cerej = 0 * Bcerej; break;
                case 0: Custo_cerej = 50 * Bcerej; break;
                case 1: Custo_cerej = 100 * Bcerej; break;
                case 2: Custo_cerej = 200 * Bcerej; break;
                case 3: Custo_cerej = 500 * Bcerej; break;
                case 4: Custo_cerej = 1000 * Bcerej; break;
                case 5: Custo_cerej = 2000 * Bcerej; break;
                case 6: Custo_cerej = 5000 * Bcerej; break;
                case 7: Custo_cerej = 10000 * Bcerej; break;
            }

            custo_cereja.Text = $"A${Custo_cerej}";

            AtualizarPreco();
            if (Custo_total > Grana)
            {
                Custo_t_label.ForeColor = Color.DarkRed;
            }
            else Custo_t_label.ForeColor = Color.Black;
        }

        private void conf1_label_CheckedChanged(object sender, EventArgs e)
        {
            if (conf1_label.Checked)
            {
                conf1.Enabled = true;
            }
            else
            {
                conf1.Enabled = false;
                conf1.SelectedIndex = -1;
            }
        }

        private void conf2_label_CheckedChanged(object sender, EventArgs e)
        {
            if (conf2_label.Checked)
            {
                conf2.Enabled = true;
            }
            else
            {
                conf2.Enabled = false;
                conf2.SelectedIndex = -1;
            }
        }

        private void cerej_label_CheckedChanged(object sender, EventArgs e)
        {
            if (cerej_label.Checked)
            {
                cerej.Enabled = true;
            }
            else
            {
                cerej.Enabled = false;
                cerej.SelectedIndex = -1;
            }
        }


        private void AtualizarPreco()
        {
            double preco = tortaRepo.PrecoTorta(
                massas.SelectedIndex,
                cobert.SelectedIndex,
                conf1.SelectedIndex,
                conf2.SelectedIndex,
                cerej.SelectedIndex,
                1, 1, 1, 1
            );

            Custo_total = preco;
            Custo_t_label.Text = $"A${Custo_total}";
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            int custo = 120;
            if (Grana > custo - 1)
            {
                Grana -= 120;
                Grana_label.Text = $"A$ {Grana}";
                Upg_Cob = 1;
                cobert.Visible = true;
                cobert_label.Enabled = true;
                cobert_label.Visible = true;
                custo_cobertura.Enabled = true;
                custo_cobertura.Visible = true;
                Upg_1.Visible = false;
                Upg_1.Enabled = false;

            }
            UpgEmTela--;
        }

        private void Upg_padeiro_Click(object sender, EventArgs e)
        {
            if (padeiros == 0)
            {
                if (Grana > custo_pad)
                {
                    Grana -= custo_pad;
                    padeiros += 1;
                    custo_pad = padeiros + 1 * 10;
                    Upg_padeiro.Text = $"Novo Padeiro: ${custo_pad}";
                    label_pad.Text = $"{padeiros} Padeiros";
                    barra_pad.Visible = true;
                }

            }
            else
            {
                if (Grana > custo_pad)
                {
                    Grana -= custo_pad;
                    padeiros += 1;
                    custo_pad = padeiros + 2 * 10;
                    Upg_padeiro.Text = $"Novo Padeiro: ${custo_pad}";
                    label_pad.Text = $"{padeiros} Padeiros";
                }
            }
        }

        private void Upg_caixista_Click(object sender, EventArgs e)
        {
            if (caixista == 0)
            {
                if (Grana > custo_caixa)
                {
                    Grana -= custo_caixa;
                    caixista += 1;
                    custo_caixa = caixista + 4 * 3;
                    Upg_caixista.Text = $"Novo Caixa: ${custo_caixa}";
                    label_caixa.Text = $"{caixista} Caixas";
                    barra_caixa.Visible = true;
                }

            }
            else
            {
                if (Grana > custo_caixa)
                {
                    Grana -= custo_caixa;
                    caixista += 1;
                    custo_caixa = caixista + 4 * 10;
                    Upg_caixista.Text = $"Novo Caixa: ${custo_caixa}";
                    label_caixa.Text = $"{caixista} Caixas";
                }
            }
        }

        private void barra_pad_Click(object sender, EventArgs e)
        {

        }


        public void CriarBotaoUpgrade(string texto, int custo, EventHandler acaoClique)
        {
            Button botao = new Button();
            botao.Text = $"{texto}: A${custo}";
            botao.Location = new Point(Upg_1.Location.X, Upg_1.Location.Y + 50 * UpgEmTela);
            botao.Size = Upg_1.Size;
            botao.Click += acaoClique;
            botao.Cursor = Cursors.Hand;
            botao.FlatStyle = FlatStyle.Flat;
            botao.FlatStyle = FlatStyle.Flat;
            botao.FlatAppearance.BorderSize = 0;
            botao.BackColor = Color.White;

            this.Controls.Add(botao);
            UpgEmTela++;
        }

        private void Upg_Conf1_Click(object sender, EventArgs e)
        {
            int custo = 350;
            if (Grana > custo - 1)
            {
                Grana -= 120;
                Grana_label.Text = $"A$ {Grana}";
                Upg_conf1 = 1;
                conf1.Visible = true;
                conf1_label.Enabled = true;
                conf1_label.Visible = true;
                custo_confeito1.Enabled = true;
                custo_confeito1.Visible = true;
                this.Controls.Remove((Button)sender);
            }
            UpgEmTela--;
        }

        private void Upg_Conf2_Click(object sender, EventArgs e)
        {
            int custo = 1000;
            if (Grana >= custo)
            {
                Grana -= custo;
                Grana_label.Text = $"A$ {Grana}";
                Upg_conf2 = 1;
                conf2.Visible = true;
                conf2_label.Enabled = true;
                conf2_label.Visible = true;
                custo_confeito2.Enabled = true;
                custo_confeito2.Visible = true;
                this.Controls.Remove((Button)sender);
            }
            UpgEmTela--;
        }

        private void Upg_Cerej_Click(object sender, EventArgs e)
        {
            int custo = 2000;
            if (Grana >= custo)
            {
                Grana -= custo;
                Grana_label.Text = $"A$ {Grana}";
                Upg_cerej = 1;
                cerej.Visible = true;
                cerej_label.Enabled = true;
                cerej_label.Visible = true;
                custo_cereja.Enabled = true;
                custo_cereja.Visible = true;
                this.Controls.Remove((Button)sender);
            }
            UpgEmTela--;
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            timer.Stop();

            usuarioLogado.grana = Grana;
            usuarioLogado.padeiros = padeiros;
            usuarioLogado.caixistas = caixista;
            usuarioLogado.Upg_Cob = Upg_Cob;
            usuarioLogado.Upg_conf1 = Upg_conf1;
            usuarioLogado.Upg_conf2 = Upg_conf2;
            usuarioLogado.Upg_cerej = Upg_cerej;
            usuarioLogado.Upg_Bprice = Upg_Bprice;
            usuarioLogado.Upg_Mprice = Upg_Mprice;
            usuarioLogado.Bmassa = Bmassa;
            usuarioLogado.Bcobert = Bcobert;
            usuarioLogado.Bconf = Bconf;
            usuarioLogado.Bcerej = Bcerej;
            usuarioLogado.price_bonus = price_bonus;
            usuarioLogado.price_mult = price_mult;

            Usuario_Repo userRepo = new Usuario_Repo(connectionString);
            userRepo.Salvar(usuarioLogado);

            Application.Exit();
        }
    }
}


