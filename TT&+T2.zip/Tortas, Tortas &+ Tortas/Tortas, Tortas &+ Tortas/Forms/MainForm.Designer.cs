﻿namespace Tortas__Tortas____Tortas
{
    partial class MainForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            cuzinho = new Button();
            cobert_label = new CheckBox();
            conf1_label = new CheckBox();
            massas = new ComboBox();
            cobert = new ComboBox();
            conf1 = new ComboBox();
            massa_label = new Label();
            Tortas_label = new Label();
            Vender = new Button();
            Grana_label = new Label();
            custo_massa = new Label();
            Custo_t_label = new Label();
            Price_label = new Label();
            conf2 = new ComboBox();
            conf2_label = new CheckBox();
            cerej = new ComboBox();
            cerej_label = new CheckBox();
            custo_cobertura = new Label();
            custo_confeito1 = new Label();
            custo_confeito2 = new Label();
            custo_cereja = new Label();
            backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            upg_label = new Label();
            Upg_1 = new Button();
            Upg_padeiro = new Button();
            Upg_caixista = new Button();
            barra_caixa = new ProgressBar();
            barra_pad = new ProgressBar();
            label_caixa = new Label();
            label_pad = new Label();
            SuspendLayout();
            // 
            // cuzinho
            // 
            cuzinho.BackColor = Color.White;
            cuzinho.Cursor = Cursors.Hand;
            cuzinho.FlatAppearance.BorderSize = 0;
            cuzinho.FlatStyle = FlatStyle.Flat;
            cuzinho.Location = new Point(372, 332);
            cuzinho.Name = "cuzinho";
            cuzinho.Size = new Size(80, 34);
            cuzinho.TabIndex = 0;
            cuzinho.Text = "Cozinhar";
            cuzinho.UseVisualStyleBackColor = false;
            cuzinho.Click += button1_Click;
            // 
            // cobert_label
            // 
            cobert_label.AutoSize = true;
            cobert_label.Location = new Point(298, 97);
            cobert_label.Name = "cobert_label";
            cobert_label.Size = new Size(79, 19);
            cobert_label.TabIndex = 10;
            cobert_label.Text = "Cobertura";
            cobert_label.UseVisualStyleBackColor = true;
            cobert_label.CheckedChanged += checkBox1_CheckedChanged;
            // 
            // conf1_label
            // 
            conf1_label.AutoSize = true;
            conf1_label.Location = new Point(298, 151);
            conf1_label.Name = "conf1_label";
            conf1_label.Size = new Size(81, 19);
            conf1_label.TabIndex = 12;
            conf1_label.Text = "Confeito 1";
            conf1_label.UseVisualStyleBackColor = true;
            conf1_label.CheckedChanged += conf1_label_CheckedChanged;
            // 
            // massas
            // 
            massas.BackColor = Color.White;
            massas.DropDownStyle = ComboBoxStyle.DropDownList;
            massas.FlatStyle = FlatStyle.Flat;
            massas.FormattingEnabled = true;
            massas.Items.AddRange(new object[] { "Trigo", "Fubá" });
            massas.Location = new Point(387, 43);
            massas.Name = "massas";
            massas.Size = new Size(121, 23);
            massas.TabIndex = 13;
            massas.SelectedIndexChanged += Massas_SelectedIndexChanged;
            // 
            // cobert
            // 
            cobert.BackColor = Color.White;
            cobert.DropDownStyle = ComboBoxStyle.DropDownList;
            cobert.FlatStyle = FlatStyle.Flat;
            cobert.FormattingEnabled = true;
            cobert.Items.AddRange(new object[] { "Glacê", "Creme", "Chocolate" });
            cobert.Location = new Point(387, 97);
            cobert.Name = "cobert";
            cobert.Size = new Size(121, 23);
            cobert.TabIndex = 14;
            cobert.SelectedIndexChanged += cobert_SelectedIndexChanged;
            // 
            // conf1
            // 
            conf1.DropDownStyle = ComboBoxStyle.DropDownList;
            conf1.FlatStyle = FlatStyle.Flat;
            conf1.FormattingEnabled = true;
            conf1.Items.AddRange(new object[] { "Granola", "Colorido", "Chocolate" });
            conf1.Location = new Point(387, 151);
            conf1.Name = "conf1";
            conf1.Size = new Size(121, 23);
            conf1.TabIndex = 15;
            conf1.SelectedIndexChanged += conf1_SelectedIndexChanged;
            // 
            // massa_label
            // 
            massa_label.AutoSize = true;
            massa_label.Location = new Point(317, 43);
            massa_label.Name = "massa_label";
            massa_label.Size = new Size(40, 15);
            massa_label.TabIndex = 16;
            massa_label.Text = "Massa";
            // 
            // Tortas_label
            // 
            Tortas_label.AutoSize = true;
            Tortas_label.Location = new Point(100, 249);
            Tortas_label.Name = "Tortas_label";
            Tortas_label.Size = new Size(48, 15);
            Tortas_label.TabIndex = 17;
            Tortas_label.Text = "X Tortas";
            // 
            // Vender
            // 
            Vender.BackColor = Color.White;
            Vender.Cursor = Cursors.Hand;
            Vender.FlatAppearance.BorderSize = 0;
            Vender.FlatStyle = FlatStyle.Flat;
            Vender.Font = new Font("Verdana", 9F, FontStyle.Italic, GraphicsUnit.Point, 0);
            Vender.Location = new Point(81, 314);
            Vender.Name = "Vender";
            Vender.Size = new Size(80, 34);
            Vender.TabIndex = 18;
            Vender.Text = "Vender";
            Vender.UseVisualStyleBackColor = false;
            Vender.Click += Vender_Click;
            // 
            // Grana_label
            // 
            Grana_label.AutoSize = true;
            Grana_label.Location = new Point(100, 43);
            Grana_label.Name = "Grana_label";
            Grana_label.Size = new Size(42, 15);
            Grana_label.TabIndex = 19;
            Grana_label.Text = "A$ 100";
            // 
            // custo_massa
            // 
            custo_massa.AutoSize = true;
            custo_massa.Location = new Point(514, 46);
            custo_massa.Name = "custo_massa";
            custo_massa.Size = new Size(27, 15);
            custo_massa.TabIndex = 20;
            custo_massa.Text = "A$0";
            // 
            // Custo_t_label
            // 
            Custo_t_label.AutoSize = true;
            Custo_t_label.ForeColor = SystemColors.ControlText;
            Custo_t_label.Location = new Point(400, 314);
            Custo_t_label.Name = "Custo_t_label";
            Custo_t_label.Size = new Size(27, 15);
            Custo_t_label.TabIndex = 21;
            Custo_t_label.Text = "A$0";
            // 
            // Price_label
            // 
            Price_label.AutoSize = true;
            Price_label.Location = new Point(81, 351);
            Price_label.Name = "Price_label";
            Price_label.Size = new Size(75, 15);
            Price_label.TabIndex = 22;
            Price_label.Text = "Preço: A$000";
            // 
            // conf2
            // 
            conf2.DropDownStyle = ComboBoxStyle.DropDownList;
            conf2.FlatStyle = FlatStyle.Flat;
            conf2.FormattingEnabled = true;
            conf2.Items.AddRange(new object[] { "Granola", "Colorido", "Chocolate" });
            conf2.Location = new Point(387, 203);
            conf2.Name = "conf2";
            conf2.Size = new Size(121, 23);
            conf2.TabIndex = 23;
            conf2.SelectedIndexChanged += conf2_SelectedIndexChanged;
            // 
            // conf2_label
            // 
            conf2_label.AutoSize = true;
            conf2_label.Location = new Point(296, 203);
            conf2_label.Name = "conf2_label";
            conf2_label.Size = new Size(81, 19);
            conf2_label.TabIndex = 24;
            conf2_label.Text = "Confeito 2";
            conf2_label.UseVisualStyleBackColor = true;
            conf2_label.CheckedChanged += conf2_label_CheckedChanged;
            // 
            // cerej
            // 
            cerej.DropDownStyle = ComboBoxStyle.DropDownList;
            cerej.FlatStyle = FlatStyle.Flat;
            cerej.FormattingEnabled = true;
            cerej.Items.AddRange(new object[] { "Cereja Comum", "Cereja Azul", "Cereja de Chocolate", "Cereja Dourada" });
            cerej.Location = new Point(387, 260);
            cerej.Name = "cerej";
            cerej.Size = new Size(121, 23);
            cerej.TabIndex = 25;
            cerej.SelectedIndexChanged += cerej_SelectedIndexChanged;
            // 
            // cerej_label
            // 
            cerej_label.AutoSize = true;
            cerej_label.Location = new Point(296, 259);
            cerej_label.Name = "cerej_label";
            cerej_label.Size = new Size(59, 19);
            cerej_label.TabIndex = 26;
            cerej_label.Text = "Cereja";
            cerej_label.UseVisualStyleBackColor = true;
            cerej_label.CheckedChanged += cerej_label_CheckedChanged;
            // 
            // custo_cobertura
            // 
            custo_cobertura.AutoSize = true;
            custo_cobertura.Location = new Point(514, 101);
            custo_cobertura.Name = "custo_cobertura";
            custo_cobertura.Size = new Size(27, 15);
            custo_cobertura.TabIndex = 27;
            custo_cobertura.Text = "A$0";
            // 
            // custo_confeito1
            // 
            custo_confeito1.AutoSize = true;
            custo_confeito1.Location = new Point(514, 155);
            custo_confeito1.Name = "custo_confeito1";
            custo_confeito1.Size = new Size(27, 15);
            custo_confeito1.TabIndex = 28;
            custo_confeito1.Text = "A$0";
            // 
            // custo_confeito2
            // 
            custo_confeito2.AutoSize = true;
            custo_confeito2.Location = new Point(514, 206);
            custo_confeito2.Name = "custo_confeito2";
            custo_confeito2.Size = new Size(27, 15);
            custo_confeito2.TabIndex = 29;
            custo_confeito2.Text = "A$0";
            // 
            // custo_cereja
            // 
            custo_cereja.AutoSize = true;
            custo_cereja.Location = new Point(514, 263);
            custo_cereja.Name = "custo_cereja";
            custo_cereja.Size = new Size(27, 15);
            custo_cereja.TabIndex = 30;
            custo_cereja.Text = "A$0";
            // 
            // upg_label
            // 
            upg_label.AutoSize = true;
            upg_label.Font = new Font("Segoe UI", 15F);
            upg_label.Location = new Point(637, 46);
            upg_label.Name = "upg_label";
            upg_label.Size = new Size(119, 28);
            upg_label.TabIndex = 32;
            upg_label.Text = "MELHORIAS";
            // 
            // Upg_1
            // 
            Upg_1.BackColor = Color.White;
            Upg_1.Cursor = Cursors.Hand;
            Upg_1.FlatAppearance.BorderSize = 0;
            Upg_1.FlatStyle = FlatStyle.Flat;
            Upg_1.Location = new Point(641, 223);
            Upg_1.Name = "Upg_1";
            Upg_1.Size = new Size(115, 41);
            Upg_1.TabIndex = 33;
            Upg_1.Text = "Cobertura: A$120";
            Upg_1.UseVisualStyleBackColor = false;
            Upg_1.Click += button1_Click_1;
            // 
            // Upg_padeiro
            // 
            Upg_padeiro.BackColor = Color.White;
            Upg_padeiro.Cursor = Cursors.Hand;
            Upg_padeiro.FlatAppearance.BorderColor = Color.White;
            Upg_padeiro.FlatAppearance.BorderSize = 0;
            Upg_padeiro.FlatStyle = FlatStyle.Flat;
            Upg_padeiro.Location = new Point(641, 92);
            Upg_padeiro.Name = "Upg_padeiro";
            Upg_padeiro.Size = new Size(115, 41);
            Upg_padeiro.TabIndex = 34;
            Upg_padeiro.Text = "Novo Padeiro: $0";
            Upg_padeiro.UseVisualStyleBackColor = false;
            Upg_padeiro.Click += Upg_padeiro_Click;
            // 
            // Upg_caixista
            // 
            Upg_caixista.BackColor = Color.White;
            Upg_caixista.Cursor = Cursors.Hand;
            Upg_caixista.FlatAppearance.BorderSize = 0;
            Upg_caixista.FlatStyle = FlatStyle.Flat;
            Upg_caixista.Location = new Point(641, 139);
            Upg_caixista.Name = "Upg_caixista";
            Upg_caixista.Size = new Size(115, 41);
            Upg_caixista.TabIndex = 35;
            Upg_caixista.Text = "Novo Caixa: $0";
            Upg_caixista.UseVisualStyleBackColor = false;
            Upg_caixista.Click += Upg_caixista_Click;
            // 
            // barra_caixa
            // 
            barra_caixa.Location = new Point(41, 374);
            barra_caixa.Name = "barra_caixa";
            barra_caixa.Size = new Size(168, 23);
            barra_caixa.TabIndex = 37;
            barra_caixa.Visible = false;
            // 
            // barra_pad
            // 
            barra_pad.Location = new Point(326, 387);
            barra_pad.Name = "barra_pad";
            barra_pad.Size = new Size(168, 23);
            barra_pad.TabIndex = 38;
            barra_pad.Visible = false;
            barra_pad.Click += barra_pad_Click;
            // 
            // label_caixa
            // 
            label_caixa.AutoSize = true;
            label_caixa.Location = new Point(100, 282);
            label_caixa.Name = "label_caixa";
            label_caixa.Size = new Size(51, 15);
            label_caixa.TabIndex = 39;
            label_caixa.Text = "X Caixas";
            // 
            // label_pad
            // 
            label_pad.AutoSize = true;
            label_pad.Location = new Point(94, 297);
            label_pad.Name = "label_pad";
            label_pad.Size = new Size(62, 15);
            label_pad.TabIndex = 40;
            label_pad.Text = "X Padeiros";
            // 
            // MainForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(255, 192, 192);
            ClientSize = new Size(800, 450);
            Controls.Add(label_pad);
            Controls.Add(label_caixa);
            Controls.Add(barra_pad);
            Controls.Add(barra_caixa);
            Controls.Add(Upg_caixista);
            Controls.Add(Upg_padeiro);
            Controls.Add(Upg_1);
            Controls.Add(upg_label);
            Controls.Add(custo_cereja);
            Controls.Add(custo_confeito2);
            Controls.Add(custo_confeito1);
            Controls.Add(custo_cobertura);
            Controls.Add(cerej_label);
            Controls.Add(cerej);
            Controls.Add(conf2_label);
            Controls.Add(conf2);
            Controls.Add(Price_label);
            Controls.Add(Custo_t_label);
            Controls.Add(custo_massa);
            Controls.Add(Grana_label);
            Controls.Add(Vender);
            Controls.Add(Tortas_label);
            Controls.Add(massa_label);
            Controls.Add(conf1);
            Controls.Add(cobert);
            Controls.Add(massas);
            Controls.Add(conf1_label);
            Controls.Add(cobert_label);
            Controls.Add(cuzinho);
            Name = "MainForm";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button cuzinho;
        private CheckBox cobert_label;
        private CheckBox conf1_label;
        private ComboBox massas;
        private ComboBox cobert;
        private ComboBox conf1;
        private Label massa_label;
        private Label Tortas_label;
        private Button Vender;
        private Label Grana_label;
        private Label custo_massa;
        private Label Custo_t_label;
        private Label Price_label;
        private ComboBox conf2;
        private CheckBox conf2_label;
        private ComboBox cerej;
        private CheckBox cerej_label;
        private Label custo_cobertura;
        private Label custo_confeito1;
        private Label custo_confeito2;
        private Label custo_cereja;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private Label upg_label;
        private Button Upg_1;
        private Button Upg_padeiro;
        private Button Upg_caixista;
        private ProgressBar barra_caixa;
        private ProgressBar barra_pad;
        private Label label_caixa;
        private Label label_pad;
    }
}
