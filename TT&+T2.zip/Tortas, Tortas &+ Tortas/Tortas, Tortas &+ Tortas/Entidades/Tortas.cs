﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tortas__Tortas____Tortas.Entidades
{
    class Tortas
    {
        public int id { get; set; }
        public double preco { get; set; }
        public int massa { get; set; }
        public int cobert { get; set; }
        public int conf1 { get; set; }
        public int conf2 { get; set; }
        public int cerej { get; set; }
        public int quant { get; set; }
        public double precotodas { get; set; }
        public int usuario_id { get; set; }
    }
}
