﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Tortas__Tortas____Tortas.Entidades;
using Tortas__Tortas____Tortas.Repositórios;
using static Org.BouncyCastle.Asn1.Cmp.Challenge;

namespace Tortas__Tortas____Tortas.Forms
{
    public partial class LogInForm : Form
    {
        public string nome;
        public string password;

        private System.Windows.Forms.Timer timer;

        static string connectionString = "Server=localhost;Port=3306;Database=tt_t;User=root;Password=;ConvertZeroDateTime=True;";
        usuario user = new usuario();
        Usuario_Repo user_repo = new Usuario_Repo(connectionString);

        public LogInForm()
        {
            InitializeComponent();

            timer = new System.Windows.Forms.Timer();
            timer.Interval = 1;
            timer.Tick += Timer_Tick;
            timer.Start();

        }

        private void Entrar_Click(object sender, EventArgs e)
        {
            nome = UserName.Text;
            password = PassWord.Text;

            password = user_repo.GerarHash(password);

            user.name = nome;
            user.senha = password;

            if (user_repo.entrar(user))
            {
                MainForm jogo = new MainForm(user);
                jogo.Show();
                this.Hide();
            }

            UserName.Text = "";
            PassWord.Text = "";
        }

        private void Cadastrar_Click(object sender, EventArgs e)
        {
            nome = UserName.Text;
            password = PassWord.Text;

            password = user_repo.GerarHash(password);

            user.name = nome;
            user.senha = password;

            user_repo.cadastrar(user);

            UserName.Text = "";
            PassWord.Text = "";
        }

        private void LogInForm_Load(object sender, EventArgs e)
        {

        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            User_Label.Location = new Point(this.Size.Width / 8, this.Size.Height / 4);
            UserName.Location = new Point(User_Label.Location.X + User_Label.Width + 1 + this.Size.Width / 16, this.Size.Height / 4);
            UserName.Size = new Size(this.Size.Width / 5, UserName.Size.Height);
            Senha.Location = new Point(this.Size.Width / 8, this.Size.Height / 4 + this.Height / 10);
            PassWord.Location = new Point(User_Label.Location.X + 65 + this.Size.Width / 16, this.Size.Height / 4 + this.Height/10);
            PassWord.Size = new Size(this.Size.Width / 5, PassWord.Size.Height);
            Entrar.Location = new Point(UserName.Location.X, this.Size.Height / 4 + this.Height / 4);
            Cadastrar.Location = new Point(Entrar.Location.X + Entrar.Size.Width + 1 + this.Size.Width / 16, this.Size.Height / 4 + this.Height / 4);
            tt_t.Location = new Point(this.Width/2 - tt_t.Size.Width/2 - 7, this.Height/20);
        }

        private void User_Label_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
