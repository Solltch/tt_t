﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tortas__Tortas____Tortas.Utilidade
{
    class Imagens
    {
        public static Image PegarImagem(byte[] dados)
        {
            if (dados == null || dados.Length == 0)
                return null;

            try
            {
                using (var ms = new MemoryStream(dados))
                {
                    return Image.FromStream(ms);
                }
            }
            catch
            {
                return null;
            }
        }
        public static byte[] MandarImagem(Image imagem)
        {
            if (imagem == null)
                return null;

            using (var ms = new MemoryStream())
            {
                imagem.Save(ms, imagem.RawFormat);
                return ms.ToArray();
            }
        }
    }
}
