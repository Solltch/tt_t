-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 16/06/2025 às 01:22
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `tt_t`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `tortas`
--

CREATE TABLE `tortas` (
  `id` int(11) NOT NULL,
  `preco` int(11) DEFAULT NULL,
  `massa` int(11) DEFAULT NULL,
  `cobert` int(11) DEFAULT NULL,
  `conf1` int(11) DEFAULT NULL,
  `conf2` int(11) DEFAULT NULL,
  `cerej` int(11) DEFAULT NULL,
  `quant` int(11) DEFAULT 1,
  `precotodas` double NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `tortas`
--

INSERT INTO `tortas` (`id`, `preco`, `massa`, `cobert`, `conf1`, `conf2`, `cerej`, `quant`, `precotodas`) VALUES
(280, 70, 0, 0, 0, 0, 0, 1, 70),
(281, 10, 1, -1, -1, -1, -1, 1, 0);

-- --------------------------------------------------------

--
-- Estrutura para tabela `torta_usuari`
--

CREATE TABLE `torta_usuari` (
  `id_usuario` int(11) NOT NULL,
  `id_torta` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuario`
--

CREATE TABLE `usuario` (
  `id` int(11) NOT NULL,
  `grana` int(11) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `senha` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `tortas`
--
ALTER TABLE `tortas`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `torta_usuari`
--
ALTER TABLE `torta_usuari`
  ADD PRIMARY KEY (`id_usuario`,`id_torta`),
  ADD KEY `id_torta` (`id_torta`);

--
-- Índices de tabela `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `tortas`
--
ALTER TABLE `tortas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=282;

--
-- AUTO_INCREMENT de tabela `usuario`
--
ALTER TABLE `usuario`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `torta_usuari`
--
ALTER TABLE `torta_usuari`
  ADD CONSTRAINT `torta_usuari_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id`),
  ADD CONSTRAINT `torta_usuari_ibfk_2` FOREIGN KEY (`id_torta`) REFERENCES `tortas` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
