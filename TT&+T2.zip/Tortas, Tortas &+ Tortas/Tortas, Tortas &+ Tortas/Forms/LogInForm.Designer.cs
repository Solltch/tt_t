﻿namespace Tortas__Tortas____Tortas.Forms
{
    partial class LogInForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            UserName = new TextBox();
            PassWord = new TextBox();
            User_Label = new Label();
            Entrar = new Button();
            Senha = new Label();
            Cadastrar = new Button();
            tt_t = new Label();
            SuspendLayout();
            // 
            // UserName
            // 
            UserName.BorderStyle = BorderStyle.FixedSingle;
            UserName.Location = new Point(182, 81);
            UserName.Name = "UserName";
            UserName.Size = new Size(203, 23);
            UserName.TabIndex = 0;
            // 
            // PassWord
            // 
            PassWord.BorderStyle = BorderStyle.FixedSingle;
            PassWord.Location = new Point(182, 143);
            PassWord.Name = "PassWord";
            PassWord.Size = new Size(203, 23);
            PassWord.TabIndex = 1;
            // 
            // User_Label
            // 
            User_Label.AutoSize = true;
            User_Label.FlatStyle = FlatStyle.Flat;
            User_Label.Font = new Font("Bodoni MT", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            User_Label.Location = new Point(104, 81);
            User_Label.Name = "User_Label";
            User_Label.Size = new Size(63, 19);
            User_Label.TabIndex = 2;
            User_Label.Text = "Usuário";
            // 
            // Entrar
            // 
            Entrar.BackColor = Color.White;
            Entrar.FlatAppearance.BorderColor = Color.White;
            Entrar.FlatAppearance.BorderSize = 0;
            Entrar.FlatStyle = FlatStyle.Flat;
            Entrar.Location = new Point(182, 271);
            Entrar.Name = "Entrar";
            Entrar.Size = new Size(75, 23);
            Entrar.TabIndex = 4;
            Entrar.Text = "Entrar";
            Entrar.UseVisualStyleBackColor = false;
            Entrar.Click += Entrar_Click;
            // 
            // Senha
            // 
            Senha.AutoSize = true;
            Senha.Font = new Font("Bodoni MT", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Senha.Location = new Point(104, 143);
            Senha.Name = "Senha";
            Senha.Size = new Size(51, 19);
            Senha.TabIndex = 6;
            Senha.Text = "Senha";
            // 
            // Cadastrar
            // 
            Cadastrar.BackColor = Color.White;
            Cadastrar.FlatAppearance.BorderSize = 0;
            Cadastrar.FlatStyle = FlatStyle.Flat;
            Cadastrar.Location = new Point(285, 271);
            Cadastrar.Name = "Cadastrar";
            Cadastrar.Size = new Size(75, 23);
            Cadastrar.TabIndex = 7;
            Cadastrar.Text = "Cadastrar";
            Cadastrar.UseVisualStyleBackColor = false;
            Cadastrar.Click += Cadastrar_Click;
            // 
            // tt_t
            // 
            tt_t.AutoSize = true;
            tt_t.FlatStyle = FlatStyle.Flat;
            tt_t.Font = new Font("MV Boli", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            tt_t.Location = new Point(182, 9);
            tt_t.Name = "tt_t";
            tt_t.Size = new Size(462, 31);
            tt_t.TabIndex = 8;
            tt_t.Text = "TORTAS, TORTAS E MAIS TORTAS";
            tt_t.Click += label1_Click;
            // 
            // LogInForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(255, 192, 192);
            ClientSize = new Size(800, 450);
            Controls.Add(tt_t);
            Controls.Add(Cadastrar);
            Controls.Add(Senha);
            Controls.Add(Entrar);
            Controls.Add(User_Label);
            Controls.Add(PassWord);
            Controls.Add(UserName);
            Name = "LogInForm";
            Text = "Form2";
            Load += LogInForm_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox UserName;
        private TextBox PassWord;
        private Label User_Label;
        private Button Entrar;
        private Label Senha;
        private Button Cadastrar;
        private Label tt_t;
    }
}