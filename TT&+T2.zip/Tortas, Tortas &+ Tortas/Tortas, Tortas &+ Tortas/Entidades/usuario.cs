﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tortas__Tortas____Tortas.Entidades
{
    public class usuario
    {
        public int id { get; set; }
        public double grana { get; set; }
        public string name { get; set; }
        public string senha { get; set; }
        public int padeiros { get; set; }
        public int caixistas { get; set; }
        public int Upg_Cob { get; set; }
        public int Upg_conf1 { get; set; }
        public int Upg_conf2 { get; set; }
        public int Upg_cerej { get; set; }
        public int Upg_Bprice { get; set; }
        public int Upg_Mprice { get; set; }
        public double Bmassa { get; set; }
        public double Bcobert { get; set; }
        public double Bconf { get; set; }
        public double Bcerej { get; set; }
        public double price_bonus { get; set; }
        public double price_mult { get; set; }
    }
}
